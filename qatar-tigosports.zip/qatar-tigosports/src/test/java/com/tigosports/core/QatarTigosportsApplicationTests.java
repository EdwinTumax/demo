package com.tigosports.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QatarTigosportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
